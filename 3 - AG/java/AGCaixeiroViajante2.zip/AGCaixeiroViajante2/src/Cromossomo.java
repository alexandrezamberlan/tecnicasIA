import java.util.LinkedList;
import java.util.List;


public class Cromossomo implements Comparable<Cromossomo>{
    public List<String> caminho = new LinkedList<>();	
    public int aptidao; //calculo é inverso 'a solução, quanto mais restrições feridas, mais alto é o valor da aptidão, ou seja, a solução é aptidao == 0
    public int porcentagemAptidao;

    public Cromossomo(List<String> valor, Mapa mapa) {
        this.caminho.addAll(valor);
        calcularAptidao(mapa);
        this.porcentagemAptidao = calcularPorcentagemAptidao();
    }

    private void calcularAptidao(Mapa mapa) { //heurística do sistema ou do AG
        this.aptidao = 0;
        //valor [4 3 1 2 6 5 9 8 7]
        String conexao; //"4,3"
        for (int i = 0; i < caminho.size() - 1; i++) {
            conexao = "" + caminho.get(i) + "," + caminho.get(i + 1);

            if (!mapa.listaConexoes.contains(conexao)) {
                    aptidao+=10; //feriu uma restrição de conexão
            }
        }

        //falta adicionar a restrição da cidade faltante ou de cidade repetida
        for (int i = 1; i <= mapa.quantidadePontos; i++) {
            if (!caminho.contains(i+"")) {
                aptidao+=5;
            }
        }
    }

    private int calcularPorcentagemAptidao() {
        return 1;
    }

    @Override
    public String toString() {
        return "rota=" + caminho + ", aptidao=" + aptidao;
    }

    @Override
    public int compareTo(Cromossomo cromossomo) {
        if (this.aptidao < cromossomo.aptidao) {
            return -1;
        }
        return 1;
    }
}
