import java.util.LinkedList;
import java.util.List;

public class Teste {
	public static void main(String a[]) {
		List<String> lista = new LinkedList<>();
		
		lista.add("5");
		lista.add("3");
		lista.add("1");
		lista.add("2");
		lista.add("8");
		lista.add("4");
		lista.add("7");
		lista.add("6");
		System.out.println(lista);
	}

}
