import java.util.*; import jason.*; import jason.asSyntax.*; import jason.environment.*;

public class AmbienteQuarto extends Environment {
    Literal trd  = Literal.parseLiteral("trancada(porta)");
    Literal ntrd = Literal.parseLiteral("~trancada(porta)");
    boolean portaTrancada = true;
    
    @Override
	public void init(String[] args) {
        // percepcoes iniciais
        addPercept(trd);
    }   
    // Implementacao das acoes basicas do agente
    @Override
    public boolean executeAction(String ag, Structure act) {
	    clearPercepts();
	    if (act.getFunctor().equals("trancar"))
		    portaTrancada = true;
	    if (act.getFunctor().equals("destrancar"))
		    portaTrancada = false;
	    // atualiza percepcoes de estados ocorridos no ambiente
	    if (portaTrancada) {
		    addPercept(trd);
	    } else { addPercept(ntrd); }
	    return true;
    }
}
